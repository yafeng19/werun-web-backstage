<template>
  <div id="main_wrap">
    <div style="height: 70px"></div>
    <router-view />
  </div>
</template>
<script>
export default {};
</script>
<style scoped>
#main_wrap {
  /* position:absolute;
    width: 83vw;;
    height:90vh;;
    left:17vw;
    top:20vh;
     */
  position: absolute;
  left: 260px;
  top: 0px;
  bottom: 0px;
  right: 0px;
  background-color: rgb(240, 241, 244);
  height: 100%;
  margin: 0px;
}
</style>